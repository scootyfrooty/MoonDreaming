# script_chapter4.rpy
#
# Chapter 4. Ana takes a call from her sister while driving home.

label chapter_four:
    scene bg car sunset with fadehold
    play music "pad_low.mp3"
    show ana default with easeinleft:
        xpos 100
        ypos 30

    n "As I was driving home from work, my ringtone blared out of the car's speakers." 
    
    n "Aghh, my sister. I picked up the call."

    show sophia sprite with easeinbottom:
        xpos 60
        ypos 5

    show ana default with ease:
        xzoom -1.0
        xpos 600
        ypos 30

    show sophia sprite at hop

    o "Hey Ana!! I finally got time to call you, the baby is down for a nap and Carlos is making dinner, so my hands are free."

    o "How are you doing?! How's the new job?"

    show ana default at hop

    a "Hi Sophia! It's been good, I've been there 8 months so it's barely new any more."
    
    a "But y'know, crunching numbers, turning a profit."

    nvl clear

    o "Ahh 8 months is still rookie numbers! You'll get it when you're in your 30s. Is it challenging?"

    a "Nothing I can't handle! Accounting was a good choice, Mama and Papa were right about the money. "

    o "I'm so happy to hear that!" 
    
    o "I know they were worried about you back when you were in high school since your grades 
    weren't the best."

    a "I don't think a few B minuses were actually worth being worried about."

    o "Well, you know how they are!"

    nvl clear

    o "What else is up? Any hot dates recently?"

    a "Ahh, some cute guys but they didn't really go anywhere. I'll keep trying."

    o "Yeahh, I certainly don't miss dating!"

    a "How are Carlos and baby Davey?"

    o "They're doing great! Davey is exhausting though, I think I get about 10 minutes of free time per day and 3 hours of sleep. "

    o "Speaking of which, Carlos just finished dinner, I gotta run! Good talking! Love you!"

    a "Bye! Love you too!"

    hide sophia sprite with easeoutbottom

    show ana default with ease:
        xzoom 1.0
        xpos 100
        ypos 30

    n "Mannn. She's so much older than me she often feels more like a mom than a sister. She's the golden child too, I was 
    always following in her footsteps. Effortlessly put-together, polite, straight As, and a big girl job right out of college. "

    nvl clear
    scene bg apt sunset with dissolve
    
    show ana default with dissolve:
        xpos 100
        ypos 30

    n "I pull into my parking space and head upstairs to my apartment. I forgot to get groceries on the way home, so I guess 
    I'll order takeout. Or check the fridge and see if there's any left overs."

    scene bg livingroom sunset2 with dissolve
    nvl clear

    show ana default with dissolve:
        xpos 100
        ypos 30

    n "There's leftover pizza...I guess that'll work."

    scene bg bedroom sunset2 with dissolve
    nvl clear

    show ana default with dissolve:
        xpos 100
        ypos 30

    n "I settled down on my bed with my pizza and my laptop, and opened up one of my favorite true crime Youtubers. "
    
    n "The sting of talking to my family and feeling inadequate hurts a bit less with carbs and cheap thrills. "

    nvl clear
    scene bg bedroom night with fadehold
    show ana default with dissolve:
        xpos 200
        ypos 30

    n "For a few hours, I melted into my bed. A cheesy, tragedy fueled puddle of goo. "
    
    n "Something about hearing about the worst possible scenarios and the worst possible people was comforting. 
    It made me feel safer, and a little bit more prepared."

    n "I winced when I caught a glimpse of my scrunched up, vacant face looking back at me from the laptop screen. With the crumbs 
    of pizza spilling onto my mattress, I felt more like a lazy teenager than a successful adult woman."

    n "Honestly maybe I could learn something from that Instagram lady." 
    
    n "Either become more successful, or stop giving a fuck about what anyone thinks. I give way too many fucks. "

    show ana default with ease:
        xzoom -1.0
        xpos 600
        ypos 30

    show instagram sprite with easeinbottom:
        xpos 60
        ypos 5

    n "I opened up her page and looked at the courses she offered. Mostly yoga stuff, tantra. \"Awaken Your Divine Feminine\"... 
    I tapped on the video."

    nvl clear

    s "Greetings, loves! I'm here with a new opportunity for you all called  \"Awakening Your Divine Feminine\". "

    s "Women come to me feeling lost. Severed from their femininity, their moon goddess connection. It's my greatest calling to 
    help restore their natural glow. "

    s "After working with me, they've told me about feeling a newfound confidence. Walking taller, making eye contact without 
    flinching, commanding rooms with their powerful voices." 
    
    s "It's beautiful watching them remember their divine right to pleasure, passion and self-love."

    s "This somatic ritual is key to that awakening. We will dive deep into our shadow selves during the full moon, and emerge 
    vibrating on a whole new level."

    nvl clear

    s "I only take 8 women per session - it's very intimate and transformational. Book now if you're ready for the next step 
    in your journey towards divine femininity! "

    n "...umm, okay. I don't know about moon goddess rituals. Sounds... culty. Maybe she has something more normal? "

    n "I tapped on a different video, this one just labeled \"Yoga & Breathwork: the most powerful combo you've been missing\""

    nvl clear

    s "Today I wanted to introduce you to two powerful somatic tools for transformation. "
    
    s "If you haven't tried yoga and breathwork 
    together, you're missing out! Together, they're some of the most potent tools I use in my personal life and in my sessions, and 
    have been key in tapping into my own feminine power. "
    
    s "I'll be hosting a class at the studio this Friday evening. Even if you've 
    never done either practice before, this class is for you!"

    n "That sounds a little less freaky. I've done yoga, and I assume breathwork is like those breathing exercises they give you in 
    therapy? "
    
    n "I could give the \"Basic Yoga & Breathwork\" class a try. Worst case, it ends up being just a basic class. "
    
    n "Best case, maybe I'll be the one singing in the middle of the park next month, and not giving a single fuck."

    nvl clear

    stop music fadeout 1.0
    hide ana default
    hide instagram sprite

call chapter_five from _call_chapter_five
